
"use strict";

let pose = require('./pose.js');

module.exports = {
  pose: pose,
};
